# Note
The usage of scripts `hw2-q2.py` and `hw2-q3.ipynb` remain the same as intended by the original author. 


**Also**, the output files to all the exercises in this homework are already present in the `graphs` directory. Nevertheless, the user can run the scripts to generate the output files again for verification purposes.